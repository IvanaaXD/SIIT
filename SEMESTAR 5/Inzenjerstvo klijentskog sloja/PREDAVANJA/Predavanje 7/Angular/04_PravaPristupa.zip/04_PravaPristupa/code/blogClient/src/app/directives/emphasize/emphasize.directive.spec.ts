import { EmphasizeDirective } from './emphasize.directive';

describe('EmphasizeDirective', () => {
  it('should create an instance', () => {
    const directive = new EmphasizeDirective();
    expect(directive).toBeTruthy();
  });
});
