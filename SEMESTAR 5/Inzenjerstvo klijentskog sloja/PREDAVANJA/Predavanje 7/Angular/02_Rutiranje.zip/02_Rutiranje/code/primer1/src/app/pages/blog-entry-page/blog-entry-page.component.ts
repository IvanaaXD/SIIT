import { Component, OnInit } from '@angular/core';
import { BlogEntry } from '../../model/blogEntry';

@Component({
  selector: 'app-blog-entry-page',
  templateUrl: './blog-entry-page.component.html',
  styleUrls: ['./blog-entry-page.component.css']
})
export class BlogEntryPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
