import { StefanNameValidatorDirective } from './stefan-name-validator.directive';

describe('StefanNameValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new StefanNameValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
