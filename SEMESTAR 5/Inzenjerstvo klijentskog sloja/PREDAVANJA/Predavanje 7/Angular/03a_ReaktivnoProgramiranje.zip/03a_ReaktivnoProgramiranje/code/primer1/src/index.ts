import Primer1 from './primer1/Primer1';
import Primer2 from './primer2/Primer2';
import Primer3 from './primer3/Primer3';
import Primer4 from './primer4/Primer4';
import Primer3a from './primer3a/Primer3a';
import Primer5 from './primer5/Primer5';
import Primer6 from './primer6/Primer6';
import Primer7 from './primer7/Primer7';
import Primer8 from './primer8/Primer8';
import Primer9 from './primer9/Primer9';
import Primer10 from './primer10/Primer10';
import Primer11 from './primer11/Primer11';
import Primer12 from './primer12/Primer12';

class App{
    constructor(){
        // let primer = new Primer1();
        // let primer =  new Primer2();
        // let primer =  new Primer3();
        // let primer =  new Primer3a();
        // let primer =  new Primer4();
        // let primer  = new Primer5();
        // let primer  = new Primer6();
        // let primer  = new Primer7();
        // let primer  = new Primer8();
        // let primer  = new Primer9();
        let primer  = new Primer10();
        // let primer  = new Primer11();
        // let primer  = new Primer12();
        primer.run();

    }
}

let app = new App();

