import { TitlePipe } from './title.pipe';

describe('TitlePipe', () => {
  it('create an instance', () => {
    const pipe = new TitlePipe();
    expect(pipe).toBeTruthy();
  });
});
