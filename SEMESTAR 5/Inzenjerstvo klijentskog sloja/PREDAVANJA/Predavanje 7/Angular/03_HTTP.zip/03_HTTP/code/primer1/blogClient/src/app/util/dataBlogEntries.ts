import { BlogEntry } from "../model/blogEntry";

let dataBlogEntries: BlogEntry[] = [
  {
    title: "naslov 1",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
    comments:
      [
        {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }
      ]
  },
  {
    title: "naslov 2",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
    comments:
      [
        {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }
      ]
  },
  {
    title: "naslov 3",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
    comments:
      [
        {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 100"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }
      ]
  },
  {
    title: "naslov 4",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
  },
  {
    title: "naslov 5",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
    comments:
      [
        {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }
      ]
  },
  {
    title: "naslov 6",
    description: "opis 1",
    entry: "entry 1 bla bla bla",
    comments:
      [
        {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 3"
            }
          ]
        }, {
          signedBy: "mitar_trol",
          text: "tekst komentara 1",
          comments: [
            {
              signedBy: "petar_bot",
              text: "tekst odgovora 1"
            },
            {
              signedBy: "dokoni marko",
              text: "tekst odgovora 2"
            },
            {
              signedBy: "mitar trol",
              text: "tekst odgovora 300"
            }
          ]
        }
      ]
  }
]

export default dataBlogEntries;