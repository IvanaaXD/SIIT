#!/bin/bash
# Napisati bash skript koji ispise "Hello world!"


# TODO implementirati
